import enUS from './en-US'
import uaUa from './ua-ua'
import plPL from './pl-PL'

export default {
  'en-US': enUS,
  'ua-UA': uaUa,
  'pl-PL': plPL
}
